
<?php $__env->startSection('content'); ?>

  <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <h1><?php echo e($member->email); ?></h1><br />


  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <p>This is the index page
<?php $__env->stopSection(); ?>
   

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Paschalis\speechrecognition\resources\views/pages/getDetails.blade.php ENDPATH**/ ?>