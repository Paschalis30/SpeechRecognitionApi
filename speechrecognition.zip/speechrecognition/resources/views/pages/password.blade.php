@extends('layouts.app')
@section('content')

  @foreach ($member as $member)

Your password is:  {{$member->password}} 


  @endforeach

 <p>This is the index page
@endsection
   
