@extends('layouts.app')
@section('content')

  @foreach ($member as $member)

  <h1>{{$member->email}}</h1><br />


  @endforeach

 <p>This is the index page
@endsection
   
