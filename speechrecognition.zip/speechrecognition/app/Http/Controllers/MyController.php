<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class MyController extends Controller
{
    
      //  public function getDetails(Request $request)
  //  {
     //   $member = DB::select('select * from member');
//return view('pages.getDetails',['member'=>$member]);

        //
   // }
           public function login(Request $request)
    {
       // $member = DB::select('select * from member where $email=$member->email('id')' );
      
  $member =
      DB::table('member')
       ->where('fullname',$request->fullname)
       ->where('email',$request->email)
       ->where('password',$request->password)
       ->get();
     $rit=[];
     
       if(count($member)>count($rit)){
       
 
return redirect('home.php');
 }

    else {
echo "<h2> The username or password dont't exist </h2>";


}
//return view('pages.getDetails',['member'=>$member]);
        
    }
       public function insert(Request $request)
    {
       $fullname = $request->input('fullname');
       $email = $request->input('email');
       $password = $request->input('password');
       $gender = $request->input('gender');
       $dateOfBirth = $request->input('dateOfBirth');
       $country = $request->input('country');

       $data=array("fullname"=>$fullname,"email"=>$email,"password"=>$password,"gender"=>$gender,"dateOfBirth"=>$dateOfBirth,"country"=>$country);
DB::table("member")->insert($data);

echo"Your registration has succesfully submitted <a href='login.php'>Login Page</a>";
        //
        
    
}

}
?>
