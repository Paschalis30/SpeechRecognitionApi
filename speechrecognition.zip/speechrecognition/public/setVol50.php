<?php


shell_exec("C:\Users\Paschalis\speechrecognition\SetVol.exe setvol 50");


?>


<script>
    window.location.assign("home.php");

    </script>
