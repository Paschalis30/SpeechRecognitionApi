<?php
      
    

        
        $myfile = fopen("C:/Users/Paschalis/Desktop/Git/Geia.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("C:/Users/Paschalis/Desktop/Git/Geia.txt"));
fclose($myfile);
     
      ?>
