
<?php


//shutdown in a minute
shell_exec('shutdown /r /d p:0:0');
?>
<script>
    window.location.assign("home.php");

    </script>
