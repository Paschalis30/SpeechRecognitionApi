<?php
shell_exec("start calc");










?>

<script>
    window.location.assign("home.php");

    </script>
   
    
