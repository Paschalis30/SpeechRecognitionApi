<form action="/password" method="get">


    <b>Get your password by filling out your email and fullname </b><br />
    <table>
        <tr>
            <td>
    <label id="fill">Fullname:</label>
    <input type="text" id="fullname" name="fullname" placeholder="fullname" /><br /></td>
    <td><label id="fill">Email:</label>
    <input type="email" id="email" name="email" placeholder="email" /><br /></td>

            </tr>
        </table>
    <button type="submit" >submit</button>
</form>
