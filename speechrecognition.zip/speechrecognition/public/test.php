
<?php session_start() ?>
<html>
<head>
 <title>
     Myphp

 </title> 

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
  
     <?php
          function strip_post($field) {
          if(!isset($_POST[$field])) $_POST[$field]='';
          return htmlspecialchars(stripslashes($_POST[$field]));

          }
          if(isset($_POST['username'])){
          $_SESSION['username']=strip_post('username');
          
    }

    if(!isset ( $_SESSION['counter'])) $_SESSION['counter']=1;
    else $_SESSION['counter']++;

  ?>

    <div class="container">
<?php if(!isset( $_SESSION['username'])): ?>
    <form method="post">
   Username:<input type="text" id="username" name="username" />
<button class="btn btn-primary">OK</button>
        </form>
<?php endif ?>

    <?php  if(isset($_SESSION['username']))  echo $_SESSION['username'];
    echo '<br>';
    echo "you have visited the page ".$_SESSION['counter']."times!!!";

    if($_SESSION['counter']>=10 ){  session_destroy(); }
   
        ?>
</div>
</body>
</html>
