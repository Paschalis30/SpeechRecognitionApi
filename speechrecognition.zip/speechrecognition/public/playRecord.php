<?php
   
exec('powershell -c (New-Object Media.SoundPlayer "C:/Users/Paschalis/Downloads/2020-08-04T20_16_53.532Z.wav").PlaySync();');

?>

<script>


    var delay = 500; 
setTimeout(function(){ window.location = 'home.php'; }, delay);

</script>
