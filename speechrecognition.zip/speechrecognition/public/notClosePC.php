<?php

shell_exec('shutdown /a');

?>
<script>
    window.location.assign("home.php");

    </script>
