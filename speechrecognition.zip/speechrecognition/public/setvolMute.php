<?php


shell_exec("C:\Users\Paschalis\speechrecognition\SetVol.exe setvol mute");


?>


<script>
    window.location.assign("home.php");

    </script>
