<?php
shell_exec("start wmplayer");

?>
<script>
    window.location.assign("home.php");

    </script>
