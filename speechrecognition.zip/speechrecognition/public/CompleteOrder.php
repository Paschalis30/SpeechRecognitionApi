<head><title>
    CompleteOrder
    </title>
             </head>

<body>
<center>Congratulations Your Order have succesfully submitted!!!

<h3><button onclick="window.location.href ='TractOrder.php'";>Check your TrackOrder</button></h3></center>
</body>
