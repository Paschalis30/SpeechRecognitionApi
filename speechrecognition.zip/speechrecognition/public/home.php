<!DOCTYPE html>
<html>

    <head>
<style>
.right {
 position: absolute;
  left:0px;
  //right: 30px;
  width: 0px;
  height:0px;
  //border: 0px solid #73AD21;
  padding: 0px;
}
.widgetWeather{
 position: absolute;
  //left:10px;
  right: 0px;
  width: 250px;
  height:0px;
  //border: 0px solid #73AD21;
  padding: 0px;
}
</style>
   
        <script src="Voice.js"></script>
        <title>Speech Recognition</title>

        <script>
            
            const btn = document.getElementById('btn');

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.onstart = function(){
    console.log('You can speak now!!!');
}

recognition.onresult = function(event){
    var text = event.results[0][0].transcript;
    console.log(text);
    document.getElementById('result').innerHTML = text;
    read(text);
}
             
           function read(text) {

          
                var speech = new SpeechSynthesisUtterance();
                speech.text = text;
               if (text.includes('time'))
                   speech.text = 'It is ' + new Date().getHours() + " " + new Date().getMinutes() + " right now";
               else if (text.includes('my birthday'))
                   speech.text = 'Your birthday is every day';
               else if (text.includes('love me'))
                   speech.text = 'Of course, not! You piece of junk!';



               else if (text.includes('ΠΑΟΚ'))
                   // speech.text = "ksanthi and paok are friendly teams and xanthi was" +
                   // "ruled from savidis to cheat the football matches but in the end they lost all of their targets";

                   setTimeout(function () { window.location = 'playRecord.php'; }, 2000);

               else if (text.includes('Πάρος'))
                   speech.text = 'mikonoooooos';

               else if (text.includes('What can I make now'))
                   speech.text = 'see video games or check your email';

               else if (text.includes('mobile'))
                   window.open("http://stackoverflow.com", '_blank');

               else if (text.includes('look for a job'))
                   speech.text = 'you can visit indeed,xing,linkedin and more other pages if you have time and dont ask me';
               else if (text.includes('στοίχημα'))
                   window.open("https://agones.gr/", '_blank');


               
               

                   
               else if (text.includes('open calculator'))



                   window.location.assign("openCalculator.php");
              
else if (text.includes('Open file'))



                   window.open("OpenFile.php", '_blank');


else if (text.includes('open System files'))



                   window.open("openDir.php", '_blank');




               else if (text.includes('open player'))



                   window.location.assign("openWmplayer.php");


              else if (text.includes('close PC'))



                   window.location.assign("closePC.php");



               else if (text.includes('regret'))



                   window.location.assign("notClosePC.php");




               else if (text.includes('Άνοιξε 100'))



                   window.location.assign("setVol100.php");


               else if (text.includes('Άνοιξε 50'))



                   window.location.assign("setVol50.php");


                   else if (text.includes('Άνοιξε φωνή'))



                   window.location.assign("unmute.php");


               else if (text.includes('mute'))



                   window.location.assign("setvolMute.php");


               else if (text.includes('location'))



                   window.open("myLocation.php", "_blank");

               else if (text.includes('recorder'))



                   window.open("recorder.php","_blank");

                window.speechSynthesis.speak(speech);
            }
        </script>
        <link rel="stylesheet" type="text/css" href="home.css"/>
    </head>
    <body>

    





      


          <!-- weather widget start -->
        <div class="widgetWeather">
        <div id="m-booked-weather-bl250-52571">
        <div class="booked-wzs-250-175 weather-customize" style="background-color:#137AE9;width:160px;" id="width1">
            <div class="booked-wzs-250-175_in">
            <div class="booked-wzs-250-175-data">
                <div class="booked-wzs-250-175-left-img wrz-01">
                <a target="_blank" href="https://www.booked.net/">
                    <img src="//s.bookcdn.com/images/letter/logo.gif" alt="booked.net" />
                    </a>
                    </div>
                <div class="booked-wzs-250-175-right">
                <div class="booked-wzs-day-deck">
                    <div class="booked-wzs-day-val">
                    <div class="booked-wzs-day-number">
                        <span class="plus">+</span>
                        18</div>
                    <div class="booked-wzs-day-dergee">
                        <div class="booked-wzs-day-dergee-val">&deg;</div>
                        <div class="booked-wzs-day-dergee-name">C</div>
                        </div>
                        </div>
                    <div class="booked-wzs-day">
                    <div class="booked-wzs-day-d">H: <span class="plus">+</span>
                        19&deg;</div> <div class="booked-wzs-day-n">L: <span class="plus">+</span>18&deg;</div>
                        </div> </div> <div class="booked-wzs-250-175-info">
                    <div class="booked-wzs-250-175-city">Ορεστιάδα </div>
                    <div class="booked-wzs-250-175-date">Τρίτη, 04 Αύγουστος</div> <div class="booked-wzs-left">
                    <span class="booked-wzs-bottom-l">Πρόγνωση 7 ημερών</span>
                            </div>
                              </div>
                    </div>
                </div>
            <a target="_blank" href="https://ibooked.gr/weather/orestiada-41344">
                <table cellpadding="0" cellspacing="0" class="booked-wzs-table-250">
                <tr>
                    <td>Τετ</td>
                    <td>Πεμ</td>
                    <td>Παρ</td> <td>Σαβ</td> <td>Κυρ</td> <td>Δευ</td> </tr>
                <tr>
                    <td class="week-day-ico"><div class="wrz-sml wrzs-01"></div>
                        </td>
                    <td class="week-day-ico">
                    <div class="wrz-sml wrzs-01"></div>
                        </td> <td class="week-day-ico">
                    <div class="wrz-sml wrzs-03"></div>
                             </td>
                    <td class="week-day-ico">
                    <div class="wrz-sml wrzs-03"></div>
                        </td> <td class="week-day-ico">
                    <div class="wrz-sml wrzs-03"></div></td> <td class="week-day-ico"><div class="wrz-sml wrzs-01"></div></td> </tr> <tr> <td class="week-day-val"><span class="plus">+</span>34&deg;</td> <td class="week-day-val"><span class="plus">+</span>33&deg;</td> <td class="week-day-val"><span class="plus">+</span>35&deg;</td> <td class="week-day-val"><span class="plus">+</span>34&deg;</td> <td class="week-day-val"><span class="plus">+</span>33&deg;</td> <td class="week-day-val"><span class="plus">+</span>34&deg;</td> </tr> <tr> <td class="week-day-val"><span class="plus">+</span>17&deg;</td> <td class="week-day-val"><span class="plus">+</span>18&deg;</td> <td class="week-day-val"><span class="plus">+</span>20&deg;</td> <td class="week-day-val"><span class="plus">+</span>21&deg;</td> <td class="week-day-val"><span class="plus">+</span>20&deg;</td> <td class="week-day-val"><span class="plus">+</span>18&deg;</td> </tr> </table> </a> </div></div> </div>
        <script type="text/javascript"> var css_file = document.createElement("link"); css_file.setAttribute("rel", "stylesheet"); css_file.setAttribute("type", "text/css"); css_file.setAttribute("href", 'https://s.bookcdn.com/css/w/booked-wzs-widget-275.css?v=0.0.1'); document.getElementsByTagName("head")[0].appendChild(css_file);
            function setWidgetData(data) { if (typeof (data) != 'undefined' && data.results.length > 0) { for (var i = 0; i < data.results.length; ++i) { var objMainBlock = document.getElementById('m-booked-weather-bl250-52571'); if (objMainBlock !== null) { var copyBlock = document.getElementById('m-bookew-weather-copy-' + data.results[i].widget_type); objMainBlock.innerHTML = data.results[i].html_code; if (copyBlock !== null) objMainBlock.appendChild(copyBlock); } } } else { alert('data=undefined||data.results is empty'); } } </script>
        <script type="text/javascript" charset="UTF-8" src="https://widgets.booked.net/weather/info?action=get_weather_info&ver=6&cityID=41344&type=3&scode=124&ltid=3457&domid=595&anc_id=6219&cmetric=1&wlangID=19&color=137AE9&wwidth=160&header_color=ffffff&text_color=333333&link_color=08488D&border_form=1&footer_color=ffffff&footer_text_color=333333&transparent=0"></script><!-- weather widget end -->
</div>

         <div class="right">
      <canvas  id="canvas" width="150" height="150"
style="background-color:#333">
</canvas>

<script>
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var radius = canvas.height / 2;
ctx.translate(radius, radius);
radius = radius * 0.90
setInterval(drawClock, 1000);

function drawClock() {
  drawFace(ctx, radius);
  drawNumbers(ctx, radius);
  drawTime(ctx, radius);
}

function drawFace(ctx, radius) {
  var grad;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, 2*Math.PI);
  ctx.fillStyle = 'white';
  ctx.fill();
  grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
  grad.addColorStop(0, '#333');
  grad.addColorStop(0.5, 'white');
  grad.addColorStop(1, '#333');
  ctx.strokeStyle = grad;
  ctx.lineWidth = radius*0.1;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius*0.1, 0, 2*Math.PI);
  ctx.fillStyle = '#333';
  ctx.fill();
}

function drawNumbers(ctx, radius) {
  var ang;
  var num;
  ctx.font = radius*0.15 + "px arial";
  ctx.textBaseline="middle";
  ctx.textAlign="center";
  for(num = 1; num < 13; num++){
    ang = num * Math.PI / 6;
    ctx.rotate(ang);
    ctx.translate(0, -radius*0.85);
    ctx.rotate(-ang);
    ctx.fillText(num.toString(), 0, 0);
    ctx.rotate(ang);
    ctx.translate(0, radius*0.85);
    ctx.rotate(-ang);
  }
}

function drawTime(ctx, radius){
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    //hour
    hour=hour%12;
    hour=(hour*Math.PI/6)+
    (minute*Math.PI/(6*60))+
    (second*Math.PI/(360*60));
    drawHand(ctx, hour, radius*0.5, radius*0.07);
    //minute
    minute=(minute*Math.PI/30)+(second*Math.PI/(30*60));
    drawHand(ctx, minute, radius*0.8, radius*0.07);
    // second
    second=(second*Math.PI/30);
    drawHand(ctx, second, radius*0.9, radius*0.02);
}

function drawHand(ctx, pos, length, width) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.moveTo(0,0);
    ctx.rotate(pos);
    ctx.lineTo(0, -length);
    ctx.stroke();
    ctx.rotate(-pos);
}
</script>
          </div>




<center>
  Please tell us what you want your pc to do!!!
    <button id="btn" onclick='recognition.start()'>Record</button>
        <h1 id="result"></h1>
      </center>
       
<br /><br /><br /><br /><br />


     <center><button style="color:black;background-color:gold;" onclick="window.open('speechToText.php' ,'_blank')";>Speech to text</button></center> 
      
           
            </body>
</html>
