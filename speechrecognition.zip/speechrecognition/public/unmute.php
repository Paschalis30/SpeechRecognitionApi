<?php


shell_exec("C:\Users\Paschalis\speechrecognition\SetVol.exe setvol unmute");


?>


<script>
    window.location.assign("home.php");

    </script>
